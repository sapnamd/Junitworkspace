package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import io.restassured.RestAssured;

@SpringBootApplication
public class RestAssuredApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestAssuredApplication.class, args);
		
		RestAssured.baseURI="http://localhost:8080";
		
	}

}
