package com.healthcare.healthcare.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.healthcare.healthcare.model.MedicalStaff;
import com.healthcare.healthcare.repository.MedicalStaffRepository;

@Service
public class MedicalStaffService {
    @Autowired
    private MedicalStaffRepository medicalStaffRepository;

    public List<MedicalStaff> getAllMedicalStaff() {
        return (List<MedicalStaff>) medicalStaffRepository.findAll();
    }

    public MedicalStaff getMedicalStaffById(int id) {
        Optional<MedicalStaff> staff = medicalStaffRepository.findById(id);
        return staff.orElse(null);
    }

    public MedicalStaff addMedicalStaff(MedicalStaff staff) {
        return medicalStaffRepository.save(staff);
    }

    public MedicalStaff updateMedicalStaff(int id, MedicalStaff updatedStaff) {
        Optional<MedicalStaff> optionalStaff = medicalStaffRepository.findById(id);
        if (optionalStaff.isPresent()) {
            updatedStaff.setStaffId(id);
            return medicalStaffRepository.save(updatedStaff);
        } else {
            return null;
        }
    }

    public void deleteMedicalStaff(int id) {
        medicalStaffRepository.deleteById(id);
    }
    public Optional<MedicalStaff> getStaffById(int staffId) {
        return medicalStaffRepository.findById(staffId);
    }
  
}