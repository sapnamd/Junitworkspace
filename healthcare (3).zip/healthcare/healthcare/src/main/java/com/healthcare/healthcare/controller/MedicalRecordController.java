package com.healthcare.healthcare.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.healthcare.healthcare.model.MedicalRecord;
import com.healthcare.healthcare.service.MedicalRecordService;

@RestController
@RequestMapping("/medical-records")
public class MedicalRecordController {

    @Autowired
    private MedicalRecordService medicalRecordService;

    @GetMapping
    public ResponseEntity<Iterable<MedicalRecord>> getAllMedicalRecords() {
    	Iterable<MedicalRecord> medicalRecords = medicalRecordService.getAllMedicalRecords();
        return new ResponseEntity<>(medicalRecords, HttpStatus.OK);
    }

    @GetMapping("/{recordId}")
    public ResponseEntity<MedicalRecord> getMedicalRecordById(@PathVariable int recordId) {
        MedicalRecord medicalRecord = medicalRecordService.getMedicalRecordById(recordId);
        return new ResponseEntity<>(medicalRecord, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<MedicalRecord> createMedicalRecord(@RequestBody MedicalRecord medicalRecord) {
        MedicalRecord createdMedicalRecord = medicalRecordService.createMedicalRecord(medicalRecord);
        return new ResponseEntity<>(createdMedicalRecord, HttpStatus.CREATED);
    }

    @PutMapping("/{recordId}")
    public ResponseEntity<MedicalRecord> updateMedicalRecord(
            @PathVariable int recordId,
            @RequestBody MedicalRecord medicalRecord
    ) {
        MedicalRecord updatedMedicalRecord = medicalRecordService.updateMedicalRecord(recordId, medicalRecord);
        return new ResponseEntity<>(updatedMedicalRecord, HttpStatus.OK);
    }

    @DeleteMapping("/{recordId}")
    public ResponseEntity<Void> deleteMedicalRecord(@PathVariable int recordId) {
        medicalRecordService.deleteMedicalRecord(recordId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
