package com.healthcare.healthcare.service;

import com.healthcare.healthcare.model.MedicalRecord;

public interface MedicalRecordService {
	Iterable<MedicalRecord> getAllMedicalRecords();

    MedicalRecord getMedicalRecordById(int recordId);

    MedicalRecord createMedicalRecord(MedicalRecord medicalRecord);

    MedicalRecord updateMedicalRecord(int recordId, MedicalRecord medicalRecord);

    void deleteMedicalRecord(int recordId);
}
