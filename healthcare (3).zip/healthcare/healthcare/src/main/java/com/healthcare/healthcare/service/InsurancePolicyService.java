package com.healthcare.healthcare.service;



import java.util.List;

import com.healthcare.healthcare.model.InsurancePolicy;
import com.healthcare.healthcare.model.Patient;

public interface InsurancePolicyService {
    InsurancePolicy saveInsurancePolicy(InsurancePolicy insurancePolicy);
    InsurancePolicy getInsurancePolicyById(int id);
    Iterable<InsurancePolicy> getAllInsurancePolicies();
    void deleteInsurancePolicy(int id);
}


