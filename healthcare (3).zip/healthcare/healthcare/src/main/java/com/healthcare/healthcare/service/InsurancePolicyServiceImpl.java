package com.healthcare.healthcare.service;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.healthcare.healthcare.model.InsurancePolicy;
import com.healthcare.healthcare.model.Patient;
import com.healthcare.healthcare.repository.InsurancePolicyRepository;

@Service
public class InsurancePolicyServiceImpl implements InsurancePolicyService {

    private final InsurancePolicyRepository insurancePolicyRepository;

    @Autowired
    public InsurancePolicyServiceImpl(InsurancePolicyRepository insurancePolicyRepository) {
        this.insurancePolicyRepository = insurancePolicyRepository;
    }

    @Override
    public InsurancePolicy saveInsurancePolicy(InsurancePolicy insurancePolicy) {
        return insurancePolicyRepository.save(insurancePolicy);
    }

    @Override
    public InsurancePolicy getInsurancePolicyById(int id) {
        return insurancePolicyRepository.findById(id).orElse(null);
    }

    @Override
    public Iterable<InsurancePolicy> getAllInsurancePolicies() {
        return insurancePolicyRepository.findAll();
    }

    @Override
    public void deleteInsurancePolicy(int id) {
        insurancePolicyRepository.deleteById(id);
    }



}

