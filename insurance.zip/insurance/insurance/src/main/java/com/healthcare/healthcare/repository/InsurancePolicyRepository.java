package com.healthcare.healthcare.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.healthcare.healthcare.model.InsurancePolicy;

@Repository
public interface InsurancePolicyRepository extends CrudRepository<InsurancePolicy, Integer> {
	 List<InsurancePolicy> findByInsuranceProvider_InsuranceProviderId(int insuranceProviderId); // Add custom methods if needed
}
