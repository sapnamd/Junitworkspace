package com.healthcare.healthcare.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.healthcare.healthcare.model.InsuranceProvider;
import com.healthcare.healthcare.repository.InsuranceProviderRepository;

@Service
public class InsuranceProviderServiceImpl implements InsuranceProviderService {

    private final InsuranceProviderRepository insuranceProviderRepository;

    @Autowired
    public InsuranceProviderServiceImpl(InsuranceProviderRepository insuranceProviderRepository) {
        this.insuranceProviderRepository = insuranceProviderRepository;
    }

    @Override
    public InsuranceProvider saveInsuranceProvider(InsuranceProvider insuranceProvider) {
        return insuranceProviderRepository.save(insuranceProvider);
    }

    @Override
    public InsuranceProvider getInsuranceProviderById(int id) {
        return insuranceProviderRepository.findById(id).orElse(null);
    }

    @Override
    public Iterable<InsuranceProvider> getAllInsuranceProviders() {
        return insuranceProviderRepository.findAll();
    }

    @Override
    public void deleteInsuranceProvider(int id) {
        insuranceProviderRepository.deleteById(id);
    }
   
   
}

