package com.healthcare.healthcare.service;

import com.healthcare.healthcare.model.InsuranceProvider;

public interface InsuranceProviderService {
    InsuranceProvider saveInsuranceProvider(InsuranceProvider insuranceProvider);
    InsuranceProvider getInsuranceProviderById(int id);
    Iterable<InsuranceProvider> getAllInsuranceProviders();
    void deleteInsuranceProvider(int id);
    

}
