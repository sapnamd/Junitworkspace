package com.healthcare.healthcare.service;



import com.healthcare.healthcare.model.InsurancePolicy;

public interface InsurancePolicyService {
    InsurancePolicy saveInsurancePolicy(InsurancePolicy insurancePolicy);
    InsurancePolicy getInsurancePolicyById(int id);
    Iterable<InsurancePolicy> getAllInsurancePolicies();
    void deleteInsurancePolicy(int id);
}


