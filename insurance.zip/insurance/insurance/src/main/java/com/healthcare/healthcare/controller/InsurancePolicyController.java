package com.healthcare.healthcare.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.healthcare.healthcare.model.InsurancePolicy;
import com.healthcare.healthcare.service.InsurancePolicyService;
@CrossOrigin
@RestController
@RequestMapping("/insurance-policies")
public class InsurancePolicyController {

    private final InsurancePolicyService insurancePolicyService;

    @Autowired
    public InsurancePolicyController(InsurancePolicyService insurancePolicyService) {
        this.insurancePolicyService = insurancePolicyService;
    }

    @PostMapping
    public ResponseEntity<InsurancePolicy> createInsurancePolicy(@RequestBody InsurancePolicy insurancePolicy) {
        InsurancePolicy createdPolicy = insurancePolicyService.saveInsurancePolicy(insurancePolicy);
        return new ResponseEntity<>(createdPolicy, HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    public ResponseEntity<InsurancePolicy> getInsurancePolicy(@PathVariable("id") int id) {
        InsurancePolicy policy = insurancePolicyService.getInsurancePolicyById(id);
        return policy != null ? new ResponseEntity<>(policy, HttpStatus.OK) : new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @GetMapping
    public ResponseEntity<Iterable<InsurancePolicy>> getAllInsurancePolicies() {
       Iterable<InsurancePolicy> policies = insurancePolicyService.getAllInsurancePolicies();
        return new ResponseEntity<>(policies, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteInsurancePolicy(@PathVariable("id") int id) {
        insurancePolicyService.deleteInsurancePolicy(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
 
    
    
//    @GetMapping("/patients/{providerId}")
//    public ResponseEntity<List<Patient>> getPatientsByPolicyProviderId(@PathVariable("providerId") int providerId) {
//        Iterable<InsurancePolicy> policies = insurancePolicyService.getPoliciesByProviderId(providerId);
//        
//        if (policies == null) {
//            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
//        }
//        
//        List<Patient> patients = new ArrayList<>();
//        for (InsurancePolicy policy : policies) {
//            if (policy.getPatient() != null) { // Check if patients associated with the policy are not null
//                patients.add(policy.getPatient());
//            }
//        }
//        
//        if (patients.isEmpty()) {
//            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
//        }
//        
//        return new ResponseEntity<>(patients, HttpStatus.OK);
//    }

}
