package com.healthcare.healthcare.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.healthcare.healthcare.model.InsuranceProvider;

@Repository
public interface InsuranceProviderRepository extends CrudRepository<InsuranceProvider, Integer> {
    // Add custom methods if needed
}
