package com.healthcare.healthcare.model;

import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "insurance_policy")
public class InsurancePolicy<Patient> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "policy_id")
    private Long policyId;

    @ManyToOne
    @JoinColumn(name = "patient_id", referencedColumnName = "patientId")
    private Patient patient;

    @ManyToOne
    @JoinColumn(name = "insurance_provider_id", referencedColumnName = "insuranceProviderId")
    private InsuranceProvider insuranceProvider;

    @Column(name = "policy_number")
    private String policyNumber;

    @Column(name = "coverage_details")
    private String coverageDetails;


    // Constructor without fields
    public InsurancePolicy() {
    }

    // Constructors with fields
    public InsurancePolicy(Patient patient, InsuranceProvider insuranceProvider, String policyNumber, String coverageDetails) {
        this.patient = patient;
        this.insuranceProvider = insuranceProvider;
        this.policyNumber = policyNumber;
        this.coverageDetails = coverageDetails;
    }

    // Getters and Setters for all fields

    public Long getPolicyId() {
        return policyId;
    }

    public void setPolicyId(Long policyId) {
        this.policyId = policyId;
    }

    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public InsuranceProvider getInsuranceProvider() {
        return insuranceProvider;
    }

    public void setInsuranceProvider(InsuranceProvider insuranceProvider) {
        this.insuranceProvider = insuranceProvider;
    }

    public String getPolicyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    public String getCoverageDetails() {
        return coverageDetails;
    }

    public void setCoverageDetails(String coverageDetails) {
        this.coverageDetails = coverageDetails;
    }
    
    // Other methods as needed
}
