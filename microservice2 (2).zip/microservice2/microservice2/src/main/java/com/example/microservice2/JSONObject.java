package com.example.microservice2;

public class JSONObject {

	public void put(String string, String string2) {
		// TODO Auto-generated method stub
		
	}

}
