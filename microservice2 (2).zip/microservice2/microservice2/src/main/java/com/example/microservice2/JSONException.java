package com.example.microservice2;

public class JSONException extends Exception {

}
