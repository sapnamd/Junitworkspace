package com.example.microservice3;

public class JSONObject {

	public void put(String string, String string2) {
		// TODO Auto-generated method stub
		
	}

}
