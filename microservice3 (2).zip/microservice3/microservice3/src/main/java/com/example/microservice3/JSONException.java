package com.example.microservice3;

public class JSONException extends Exception {

}
