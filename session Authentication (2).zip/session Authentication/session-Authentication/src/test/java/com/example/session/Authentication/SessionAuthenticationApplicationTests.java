package com.example.session.Authentication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SessionAuthenticationApplicationTests {

	@Test
	void contextLoads() {
	}

}
