package com.example.session.Authentication;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.*;

@SpringBootApplication
@RestController
public class SessionAuthApplication {

    // In-memory storage for user sessions (simulate database)
    private static final Map<String, String> users = new HashMap<>();

    public static void main(String[] args) {
        SpringApplication.run(SessionAuthApplication.class, args);
    }

    @PostMapping("/login")
    public String login(@RequestParam String username, @RequestParam String password, HttpSession session) {
        // Simulating authentication logic (Replace with your authentication mechanism)
        if ("user".equals(username) && "password".equals(password)) {
            String sessionId = UUID.randomUUID().toString();
            session.setAttribute("user", username);
            users.put(sessionId, username);
            return "Login successful! Session ID: " + sessionId;
        } else {
            return "Invalid credentials";
        }
    }

    @GetMapping("/secured")
    public String securedEndpoint(HttpSession session) {
        // Accessing a secured endpoint using session
        String username = (String) session.getAttribute("user");
        if (username != null) {
            return "Hello, " + username + "! This is a secured endpoint.";
        } else {
            return "Access denied. Please log in.";
        }
    }

    // Setting up a filter to intercept requests and validate sessions
    @Bean
    public FilterRegistrationBean<SessionValidationFilter> loggingFilter(){
        FilterRegistrationBean<SessionValidationFilter> registrationBean = new FilterRegistrationBean<>();

        registrationBean.setFilter(new SessionValidationFilter());
        registrationBean.addUrlPatterns("/secured/*"); // Define secured endpoints pattern

        return registrationBean;
    }

    public static class SessionValidationFilter implements Filter {
        @Override
        public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
            HttpServletRequest httpRequest = (HttpServletRequest) request;
            HttpServletResponse httpResponse = (HttpServletResponse) response;

            // Validate session for secured endpoints
            if (httpRequest.getSession(false) == null || users.get(httpRequest.getSession().getId()) == null) {
                httpResponse.getWriter().write("Unauthorized access. Please log in.");
                httpResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            } else {
                chain.doFilter(request, response);
            }
        }

        // Other Filter methods
        // init(), destroy()
    }
}
