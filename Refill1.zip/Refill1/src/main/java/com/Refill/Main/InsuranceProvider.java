package com.Refill.Main;


import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class InsuranceProvider {
    @Id
    private int insuranceProviderId;
    private String providerName;
    private long contactnumber;
    
    public InsuranceProvider(int insuranceProviderId, String providerName, long contactnumber) {
		super();
		this.insuranceProviderId = insuranceProviderId;
		this.providerName = providerName;
		this.contactnumber = contactnumber;
	}
	@Override
	public String toString() {
		return "InsuranceProvider [insuranceProviderId=" + insuranceProviderId + ", providerName=" + providerName
				+ ", contactnumber=" + contactnumber + ", getContactnumber()=" + getContactnumber()
				+ ", getInsuranceProviderId()=" + getInsuranceProviderId() + ", getProviderName()=" + getProviderName()
				+ ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString()
				+ "]";
	}
	public long getContactnumber() {
		return contactnumber;
	}
	public void setContactnumber(long contactnumber) {
		this.contactnumber = contactnumber;
	}
	// Other fields, constructors, getters, setters
	public int getInsuranceProviderId() {
		return insuranceProviderId;
	}
	public InsuranceProvider() {
		super();
		// TODO Auto-generated constructor stub
	}
	public InsuranceProvider(int insuranceProviderId, String providerName) {
		super();
		this.insuranceProviderId = insuranceProviderId;
		this.providerName = providerName;
	}
	public void setInsuranceProviderId(int insuranceProviderId) {
		this.insuranceProviderId = insuranceProviderId;
	}
	public String getProviderName() {
		return providerName;
	}
	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	
}
