package com.Refill.Service;
import com.Refill.Main.InsuranceProvider;

public interface InsuranceProviderService {
    InsuranceProvider saveInsuranceProvider(InsuranceProvider insuranceProvider);
    InsuranceProvider getInsuranceProviderById(int id);
    Iterable<InsuranceProvider> getAllInsuranceProviders();
    void deleteInsuranceProvider(int id);
    

}