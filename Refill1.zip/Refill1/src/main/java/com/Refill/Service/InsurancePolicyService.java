package com.Refill.Service;



import com.Refill.Main.InsurancePolicy;

public interface InsurancePolicyService {
    InsurancePolicy saveInsurancePolicy(InsurancePolicy insurancePolicy);
    InsurancePolicy getInsurancePolicyById(int id);
    Iterable<InsurancePolicy> getAllInsurancePolicies();
    void deleteInsurancePolicy(int id);
}


