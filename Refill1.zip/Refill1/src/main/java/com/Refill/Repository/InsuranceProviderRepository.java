package com.Refill.Repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.Refill.Main.InsuranceProvider;

@Repository
public interface InsuranceProviderRepository extends CrudRepository<InsuranceProvider, Integer> {
    // Add custom methods if needed
}
