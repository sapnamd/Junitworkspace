package com.Refill.Controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Refill.Main.InsuranceProvider;
import com.Refill.Service.InsuranceProviderService;
@CrossOrigin
@RestController
@RequestMapping("/insurance-providers")
public class InsuranceProviderController {

    private final InsuranceProviderService insuranceProviderService;

    @Autowired
    public InsuranceProviderController(InsuranceProviderService insuranceProviderService) {
        this.insuranceProviderService = insuranceProviderService;
    }

    @PostMapping
    public ResponseEntity<InsuranceProvider> createInsuranceProvider(@RequestBody InsuranceProvider insuranceProvider) {
        InsuranceProvider createdProvider = insuranceProviderService.saveInsuranceProvider(insuranceProvider);
        return new ResponseEntity<>(createdProvider, HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    public ResponseEntity<InsuranceProvider> getInsuranceProviderById(@PathVariable int id) {
        InsuranceProvider provider = insuranceProviderService.getInsuranceProviderById(id);
        if (provider != null) {
            return new ResponseEntity<>(provider, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping
    public ResponseEntity<Iterable<InsuranceProvider>> getAllInsuranceProviders() {
        Iterable<InsuranceProvider> providers = insuranceProviderService.getAllInsuranceProviders();
        return new ResponseEntity<>(providers, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteInsuranceProvider(@PathVariable int id) {
        insuranceProviderService.deleteInsuranceProvider(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
    
    

}
