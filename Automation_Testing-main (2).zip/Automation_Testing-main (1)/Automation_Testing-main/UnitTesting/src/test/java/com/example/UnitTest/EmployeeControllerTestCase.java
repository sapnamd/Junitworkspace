package com.example.UnitTest;
import java.util.List;

import org.assertj.core.api.SoftAssertions;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest
public class EmployeeControllerTestCase {

EmployeeController employeecontroller;

@BeforeEach
public void setUp() { 
employeecontroller= new EmployeeController();
}

@Test
public void testemployeeService() {
 // Arrange
 EmployeeModel employee = new EmployeeModel();
 employee.setEmployeeFirstName(null);
 // Act
 // Assert
 Assertions.assertEquals(null, employee.getEmployeeFirstName());
}

@Test
public void testGetAllEmployee() {
 // Arrange
 EmployeeController instance = new EmployeeController();
 List expectedValue = null;
 //instance.getAllEmployee();
 // Act
 //List result = instance.getAllEmployee();
 // Assert
 //Assertions.assertEquals(expectedValue, result, "getAllEmployee ");
}






@Test
public void testSetEmployeeService() {
 // Arrange
 EmployeeModel employee = new EmployeeModel();
 Object expectedValue = null;
 // Act
 //employee.setEmployeeFirstName(expectedValue);
 // Assert
 SoftAssertions softAssertions = new SoftAssertions();
 softAssertions.assertThat(employee.getEmployeeFirstName()).isEqualTo(expectedValue);
 softAssertions.assertAll();
}

//

@Test
public void testSetEmployeeService1() {
	EmployeeModel emp = new EmployeeModel();
	Object expectedValue = null;
	SoftAssertions softAss = new SoftAssertions();
	softAss.assertThat(emp.getEmployeeFirstName()).isEqualTo(expectedValue);
	softAss.assertAll();
}

//@Test
//public void testSetEmpolyeeService2() {
//	EmployeeModel emp1 = new EmployeeModel();
//	Object expectedValue = null;
//	SoftAssertions soft = new SoftAssertions();
//	soft.assertThat(emp1.getEmployeeFirstName()).isEqualTo(expectedValue);
//	soft.assertAll();
//}

}