package com.example.UnitTest;
import org.assertj.core.api.SoftAssertions;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest
public class EmployeeModelTestCase {

EmployeeModel employeemodel;

@BeforeEach
public void setUp() { 
employeemodel= new EmployeeModel();
}

@Test
public void testEmp_id() {
 // Arrange
 EmployeeModel employee = new EmployeeModel();
 employee.setEmp_id(1234L);
 // Act
 // Assert
 Assertions.assertEquals(1234L, employee.getEmp_id());
}

@Test
public void testAge() {
 // Arrange
 EmployeeModel employee = new EmployeeModel();
 employee.setAge(30);
 // Act
 // Assert
 Assertions.assertEquals(30, employee.getAge());
}

@Test
public void testEmployeeFirstName() {
 // Arrange
 EmployeeModel employee = new EmployeeModel();
 employee.setEmployeeFirstName("John");
 // Act
 // Assert
 Assertions.assertEquals("John", employee.getEmployeeFirstName());
}

@Test
public void testEmployeeLastName() {
 // Arrange
 EmployeeModel employee = new EmployeeModel();
 employee.setEmployeeLastName("John");
 // Act
 // Assert
 Assertions.assertEquals("John", employee.getEmployeeLastName());
}

@Test
public void testphoneNumber() {
 // Arrange
 EmployeeModel employee = new EmployeeModel();
 employee.setPhoneNumber("John");
 // Act
 // Assert
 Assertions.assertEquals("John", employee.getPhoneNumber());
}

@Test
public void testEmailID() {
 // Arrange
 EmployeeModel employee = new EmployeeModel();
 employee.setEmailID("John");
 // Act
 // Assert
 Assertions.assertEquals("John", employee.getEmailID());
}

@Test
public void testSetEmployeeLastName() {
 // Arrange
 EmployeeModel employee = new EmployeeModel();
 String expectedValue = null;
 // Act
 employee.setEmployeeLastName(expectedValue);
 // Assert
 SoftAssertions softAssertions = new SoftAssertions();
 softAssertions.assertThat(employee.getEmployeeLastName()).isEqualTo(expectedValue);
 softAssertions.assertAll();
}

@Test
public void testGetEmployeeFirstName() {
 // Arrange
 EmployeeModel instance = new EmployeeModel();
 String expectedValue = null;
 instance.getEmployeeFirstName();
 // Act
 String result = instance.getEmployeeFirstName();
 // Assert
 Assertions.assertEquals(expectedValue, result, "getEmployeeFirstName ");
}

@Test
public void testSetEmployeeFirstName() {
 // Arrange
 EmployeeModel employee = new EmployeeModel();
 String expectedValue = null;
 // Act
 employee.setEmployeeFirstName(expectedValue);
 // Assert
 SoftAssertions softAssertions = new SoftAssertions();
 softAssertions.assertThat(employee.getEmployeeFirstName()).isEqualTo(expectedValue);
 softAssertions.assertAll();
}

@Test
public void testGetEmployeeLastName() {
 // Arrange
 EmployeeModel instance = new EmployeeModel();
 String expectedValue = null;
 instance.getEmployeeLastName();
 // Act
 String result = instance.getEmployeeLastName();
 // Assert
 Assertions.assertEquals(expectedValue, result, "getEmployeeLastName ");
}

@Test
public void testGetEmp_id() {
 // Arrange
 EmployeeModel instance = new EmployeeModel();
 Long expectedValue = null;
 instance.getEmp_id();
 // Act
 Long result = instance.getEmp_id();
 // Assert
 Assertions.assertEquals(expectedValue, result, "getEmp_id ");
}

@Test
public void testSetEmp_id() {
 // Arrange
 EmployeeModel employee = new EmployeeModel();
 Long expectedValue = null;
 // Act
 employee.setEmp_id(expectedValue);
 // Assert
 SoftAssertions softAssertions = new SoftAssertions();
 softAssertions.assertThat(employee.getEmp_id()).isEqualTo(expectedValue);
 softAssertions.assertAll();
}

@Test
public void testGetAge() {
 // Arrange
 EmployeeModel instance = new EmployeeModel();
 int expectedValue = 0;
 instance.getAge();
 // Act
 int result = instance.getAge();
 // Assert
 Assertions.assertEquals(expectedValue, result, "getAge ");
}

@Test
public void testSetEmailID() {
 // Arrange
 EmployeeModel employee = new EmployeeModel();
 String expectedValue = null;
 // Act
 employee.setEmailID(expectedValue);
 // Assert
 SoftAssertions softAssertions = new SoftAssertions();
 softAssertions.assertThat(employee.getEmailID()).isEqualTo(expectedValue);
 softAssertions.assertAll();
}

@Test
public void testSetPhoneNumber() {
 // Arrange
 EmployeeModel employee = new EmployeeModel();
 String expectedValue = null;
 // Act
 employee.setPhoneNumber(expectedValue);
 // Assert
 SoftAssertions softAssertions = new SoftAssertions();
 softAssertions.assertThat(employee.getPhoneNumber()).isEqualTo(expectedValue);
 softAssertions.assertAll();
}

@Test
public void testSetAge1()
{
	EmployeeModel emp = new EmployeeModel();
//	float expectedValue = 0;
//	emp.setAge(expectedValue);
//	SoftAssertions softAsser = new SoftAssertions();
//	softAsser.assertThat(emp.getAge()).isEqualTo(expectedValue);
//	softAsser.assertAll();	
	String expect = null;
	emp.setEmailID(expect);
	SoftAssertions soft = new SoftAssertions();
	soft.assertThat(emp.getEmp_id()).isEqualTo(expect);
	soft.assertAll();
	
}



//@Test
//public void testSetAge2()
//{
//	EmployeeModel emp1 = new EmployeeModel();
//	float expectedValue = 0;
//	emp1.setAge(expectedValue);
//	SoftAssertions softA = new SoftAssertions();
//	softA.assertThat(emp1.getAge()).isEqualTo(expectedValue);
//	softA.assertAll();
//}



@Override
public String toString() {
	return "EmployeeModelTestCase [employeemodel=" + employeemodel + "]";
}

@Test
public void testGetPhoneNumber() {
 // Arrange
 EmployeeModel instance = new EmployeeModel();
 String expectedValue = null;
 instance.getPhoneNumber();
 // Act
 String result = instance.getPhoneNumber();
 // Assert
 Assertions.assertEquals(expectedValue, result, "getPhoneNumber ");
}

@Test
public void testGetEmailID() {
 // Arrange
 EmployeeModel instance = new EmployeeModel();
 String expectedValue = null;
 instance.getEmailID();
 // Act
 String result = instance.getEmailID();
 // Assert
 Assertions.assertEquals(expectedValue, result, "getEmailID ");
}

@Test
public void testSetAge() {
 // Arrange
 EmployeeModel employee = new EmployeeModel();
 int expectedValue = 0;
 // Act
 employee.setAge(expectedValue);
 // Assert
 SoftAssertions softAssertions = new SoftAssertions();
 softAssertions.assertThat(employee.getAge()).isEqualTo(expectedValue);
 softAssertions.assertAll();
}

}
