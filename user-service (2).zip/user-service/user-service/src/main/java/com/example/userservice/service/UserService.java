package com.example.userservice.service;

import org.springframework.stereotype.Service;

import com.example.userservice.dto.ResponseDto;
import com.example.userservice.entity.User;


public interface UserService {
	User saveUser(User user);
	ResponseDto getUser(Long userId);

}
