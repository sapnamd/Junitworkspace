package com.example.userservice.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.userservice.dto.DepartmentDto;
import com.example.userservice.dto.ResponseDto;
import com.example.userservice.dto.UserDto;
import com.example.userservice.entity.User;
import com.example.userservice.repository.UserRepository;
import com.example.userservice.service.UserService;

import lombok.AllArgsConstructor;

@Service

@AllArgsConstructor

public class UserServiceImpl implements UserService {

	@Autowired

	private UserRepository userRepository;

	private RestTemplate restTemplate;

	@Autowired

	public UserServiceImpl(UserRepository userRepository, RestTemplate restTemplate) {

		this.userRepository = userRepository;

		this.restTemplate = restTemplate;

	}

	@Override

	public User saveUser(User user) {

		return userRepository.save(user);

	}

	@Override

	public ResponseDto getUser(Long userId) {

		ResponseDto responseDto = new ResponseDto();

		User user = userRepository.findById(userId).get();

		UserDto userDto = mapToUser(user);

		ResponseEntity<DepartmentDto> responseEntity = restTemplate

				.getForEntity("http://localhost:8089/api/departments/" + user.getDepartmentId(),

						DepartmentDto.class);

		DepartmentDto departmentDto = responseEntity.getBody();

		System.out.println(responseEntity.getStatusCode());

		responseDto.setUser(userDto);

		responseDto.setDepartment(departmentDto);

		return responseDto;

	}

	private UserDto mapToUser(User user) {

		UserDto userDto = new UserDto();

		userDto.setId(user.getId());

		userDto.setFirstName(user.getFirstName());

		userDto.setLastName(user.getLastName());

		userDto.setEmail(user.getEmail());

		return userDto;

	}

}