package com.healthcare.healthcare.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.healthcare.healthcare.model.MedicalStaff;
import com.healthcare.healthcare.service.MedicalStaffService;

@RestController
@RequestMapping("/medicalstaff")
@CrossOrigin
public class MedicalStaffController {
    @Autowired
    private MedicalStaffService medicalStaffService;

    @GetMapping
    public List<MedicalStaff> getAllMedicalStaff() {
        return medicalStaffService.getAllMedicalStaff();
    }

    @GetMapping("/{id}")
    public MedicalStaff getMedicalStaffById(@PathVariable int id) {
        return medicalStaffService.getMedicalStaffById(id);
    }

    @PostMapping
    public MedicalStaff addMedicalStaff(@RequestBody MedicalStaff staff) {
        return medicalStaffService.addMedicalStaff(staff);
    }

    @PutMapping("/{id}")
    public MedicalStaff updateMedicalStaff(@PathVariable int id, @RequestBody MedicalStaff staff) {
        return medicalStaffService.updateMedicalStaff(id, staff);
    }

    @DeleteMapping("/{id}")
    public void deleteMedicalStaff(@PathVariable int id) {
        medicalStaffService.deleteMedicalStaff(id);
    }
    
    @GetMapping("/staff/{staffId}")
    public ResponseEntity<MedicalStaff> getStaffById(@PathVariable int staffId) {
        Optional<MedicalStaff> staffOptional = medicalStaffService.getStaffById(staffId);
        return staffOptional.map(staff -> new ResponseEntity<>(staff, HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }
   

}
