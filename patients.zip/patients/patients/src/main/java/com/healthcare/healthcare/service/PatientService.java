package com.healthcare.healthcare.service;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.healthcare.healthcare.model.MedicalStaff;
import com.healthcare.healthcare.model.Patient;
import com.healthcare.healthcare.repository.PatientRepository;

@Service
public class PatientService {
    @Autowired
    private PatientRepository patientRepository;

    public List<Patient> getAllPatients() {
        return (List<Patient>) patientRepository.findAll();
    }

    public Patient getPatientById(int id) {
        Optional<Patient> patient = patientRepository.findById(id);
        return patient.orElse(null);
    }

    public Patient addPatient(Patient patient) {
        return patientRepository.save(patient);
    }

    public Patient updatePatient(int id, Patient updatedPatient) {
        Optional<Patient> optionalPatient = patientRepository.findById(id);
        if (optionalPatient.isPresent()) {
            updatedPatient.setPatientId(id);
            return patientRepository.save(updatedPatient);
        } else {
            return null;
        }
    }

    public void deletePatient(int id) {
        patientRepository.deleteById(id);
    }
    public List<MedicalStaff> getStaffForPatient(int patientId) {
        String appointmentServiceBaseUrl = "http://appointment-service-base-url"; // Replace with actual base URL
        String endpoint = "/appointments/patients/" + patientId + "/staff";

        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<List<MedicalStaff>> response = restTemplate.exchange(
                appointmentServiceBaseUrl + endpoint,
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<List<MedicalStaff>>() {}
        );

        if (response.getStatusCode() == HttpStatus.OK) {
            return response.getBody();
        } else {
            // Handle error cases
            return Collections.emptyList();
        }
    }

}
