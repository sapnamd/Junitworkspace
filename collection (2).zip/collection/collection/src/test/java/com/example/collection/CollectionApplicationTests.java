package com.example.collection;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CollectionApplicationTests {

	@Test
	void contextLoads() {
	}

}
