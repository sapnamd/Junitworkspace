package com.example.collection;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;



import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Doctor {
    private String doctorId;
    private Map<String, String> demographicDetails;
    private List<String> qualifications;
    private List<String> specialities;
    private List<String> schedules;
    private Map<String, List<String>> prescriptions;
	public String getDoctorId() {
		return doctorId;
	}
	public void setDoctorId(String doctorId) {
		this.doctorId = doctorId;
	}
	public Map<String, String> getDemographicDetails() {
		return demographicDetails;
	}
	public void setDemographicDetails(Map<String, String> demographicDetails) {
		this.demographicDetails = demographicDetails;
	}
	public List<String> getQualifications() {
		return qualifications;
	}
	public void setQualifications(List<String> qualifications) {
		this.qualifications = qualifications;
	}
	public List<String> getSpecialities() {
		return specialities;
	}
	public void setSpecialities(List<String> specialities) {
		this.specialities = specialities;
	}
	public List<String> getSchedules() {
		return schedules;
	}
	public void setSchedules(List<String> schedules) {
		this.schedules = schedules;
	}
	public Map<String, List<String>> getPrescriptions() {
		return prescriptions;
	}
	public void setPrescriptions(Map<String, List<String>> prescriptions) {
		this.prescriptions = prescriptions;
	}
	public Doctor(String doctorId, Map<String, String> demographicDetails, List<String> qualifications,
			List<String> specialities, List<String> schedules, Map<String, List<String>> prescriptions) {
		super();
		this.doctorId = doctorId;
		this.demographicDetails = demographicDetails;
		this.qualifications = qualifications;
		this.specialities = specialities;
		this.schedules = schedules;
		this.prescriptions = prescriptions;
	}
	public Doctor() {
		super();
		// TODO Auto-generated constructor stub
	}

    // Constructors, getters, setters, and methods to manipulate doctor data
}
