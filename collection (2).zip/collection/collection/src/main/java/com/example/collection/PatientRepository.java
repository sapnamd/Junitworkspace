package com.example.collection;




import java.util.List;

public interface PatientRepository {
    Patient findById(String patientId);
    List<Patient> findAll();
    void save(Patient patient);
    void delete(String patientId);
    // Other methods for patient data manipulation
}
