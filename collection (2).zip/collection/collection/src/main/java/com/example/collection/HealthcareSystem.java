//package com.example.collection;
//
//public class HealthcareSystem {
//    public static void main(String[] args) {
//        // Creating Patients
//        Patient patient1 = new Patient("P001");
//        patient1.setDemographicDetail("Name", "John Doe");/
//        patient1.setDemographicDetail("Age", "35");
//        patient1.addDiseaseInformation("Fever");
//        patient1.addPrescribedMedicine("Paracetamol");
//
//        Patient patient2 = new Patient("P002");
//        patient2.setDemographicDetail("Name", "Jane Smith");
//        patient2.setDemographicDetail("Age", "28");
//        patient2.addDiseaseInformation("Headache");
//        patient2.addPrescribedMedicine("Aspirin");
//
//        // Creating Doctors
//        Doctor doctor1 = new Doctor("D001");
//        doctor1.setDemographicDetail("Name", "Dr. Smith");
//        doctor1.addQualification("MD");
//        doctor1.addSpeciality("Neurology");
//        doctor1.addSchedule("Monday 10 AM - 2 PM");
//
//        Doctor doctor2 = new Doctor("D002");
//        doctor2.setDemographicDetail("Name", "Dr. Johnson");
//        doctor2.addQualification("MBBS");
//        doctor2.addSpeciality("Cardiology");
//        doctor2.addSchedule("Tuesday 9 AM - 1 PM");
//
//        doctor1.addPrescription(patient1.getPatientId(), "Paracetamol");
//        doctor2.addPrescription(patient2.getPatientId(), "Aspirin");
//
//        // Accessing and manipulating patient and doctor data
//        // For example, printing patient and doctor details
//        System.out.println("Patient 1 Details:");
//        System.out.println("ID: " + patient1.getDemographicDetail("Name"));
//        System.out.println("Age: " + patient1.getDemographicDetail("Age"));
//        System.out.println("Disease Information: " + patient1.getDiseaseInformation());
//        System.out.println("Prescribed Medicines: " + patient1.getPrescribedMedicines());
//
//        System.out.println("\nDoctor 1 Details:");
//        System.out.println("ID: " + doctor1.getDemographicDetail("Name"));
//        System.out.println("Qualifications: " + doctor1.qualifications);
//        System.out.println("Specialities: " + doctor1.specialities);
//        System.out.println("Schedules: " + doctor1.schedules);
//        System.out.println("Prescriptions provided to patients: " + doctor1.prescriptions);
//    }
//}