package com.example.collection;

import java.util.List;

public interface DoctorRepository {
    Doctor findById(String doctorId);
    List<Doctor> findAll();
    void save(Doctor doctor);
    void delete(String doctorId);
    // Other methods for doctor data manipulation
}