package com.example.collection;


import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/patients")
public class PatientController {
    private final PatientService patientService;

    public PatientController(PatientService patientService) {
        this.patientService = patientService;
    }

    @GetMapping("/")
    public List<Patient> getAllPatients() {
        return patientService.getAllPatients();
    }

    @GetMapping("/{patientId}")
    public Patient getPatientById(@PathVariable String patientId) {
        return patientService.getPatientById(patientId);
    }

    @PostMapping("/")
    public void addPatient(@RequestBody Patient patient) {
        patientService.addPatient(patient);
    }

    @PutMapping("/{patientId}")
    public void updatePatient(@PathVariable String patientId, @RequestBody Patient updatedPatient) {
        patientService.updatePatient(patientId, updatedPatient);
    }

    @DeleteMapping("/{patientId}")
    public void deletePatient(@PathVariable String patientId) {
        patientService.deletePatient(patientId);
    }
}
