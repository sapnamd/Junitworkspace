package com.example.collection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Patient {
    private String patientId;
    private Map<String, String> demographicDetails;
    private List<String> diseaseInformation;
    private List<String> prescribedMedicines;
	public String getPatientId() {
		return patientId;
	}
	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}
	public Map<String, String> getDemographicDetails() {
		return demographicDetails;
	}
	public void setDemographicDetails(Map<String, String> demographicDetails) {
		this.demographicDetails = demographicDetails;
	}
	public List<String> getDiseaseInformation() {
		return diseaseInformation;
	}
	public void setDiseaseInformation(List<String> diseaseInformation) {
		this.diseaseInformation = diseaseInformation;
	}
	public List<String> getPrescribedMedicines() {
		return prescribedMedicines;
	}
	public void setPrescribedMedicines(List<String> prescribedMedicines) {
		this.prescribedMedicines = prescribedMedicines;
	}
	public Patient(String patientId, Map<String, String> demographicDetails, List<String> diseaseInformation,
			List<String> prescribedMedicines) {
		super();
		this.patientId = patientId;
		this.demographicDetails = demographicDetails;
		this.diseaseInformation = diseaseInformation;
		this.prescribedMedicines = prescribedMedicines;
	}
	public Patient() {
		super();
		// TODO Auto-generated constructor stub
	}

    // Constructors, getters, setters, and methods to manipulate patient data
}
