package com.example.collection;



import java.util.List;

public class PatientService {
    private final PatientRepository patientRepository;

    public PatientService(PatientRepository patientRepository) {
        this.patientRepository = patientRepository;
    }

    public List<Patient> getAllPatients() {
        return patientRepository.findAll();
    }

    public Patient getPatientById(String patientId) {
        return patientRepository.findById(patientId);
    }

    public void addPatient(Patient patient) {
        patientRepository.save(patient);
    }

    public void updatePatient(String patientId, Patient updatedPatient) {
        Patient patient = patientRepository.findById(patientId);
        if (patient != null) {
            patient.setDemographicDetails(updatedPatient.getDemographicDetails());
            patient.setDiseaseInformation(updatedPatient.getDiseaseInformation());
            patient.setPrescribedMedicines(updatedPatient.getPrescribedMedicines());
            patientRepository.save(patient);
        }
    }

    public void deletePatient(String patientId) {
        patientRepository.delete(patientId);
    }
}
