package com.example.microservice1;

public class JSONException extends Exception {

}
