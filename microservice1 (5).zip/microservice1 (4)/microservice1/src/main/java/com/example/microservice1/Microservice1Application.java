package com.example.microservice1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
//@EnableDiscoveryClient
@RestController
public class Microservice1Application {

	private String jsonObejct;



	@RequestMapping("/")
	public String home() throws JSONException{
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("message", "Hello");
		//Object jsonObejct = null;
		return jsonObejct;
	}
	
	
	
	public static void main(String[] args) {
		SpringApplication.run(Microservice1Application.class, args);
		System.out.println("hello");
	}

}
