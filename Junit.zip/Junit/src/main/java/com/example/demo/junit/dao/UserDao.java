package com.example.demo.junit.dao;

import org.springframework.stereotype.Repository;

@Repository
public class UserDao {

	public String getUserId(String userName) {
		System.out.print("UserDao Called");
		return "123445" + userName;
	}

}
