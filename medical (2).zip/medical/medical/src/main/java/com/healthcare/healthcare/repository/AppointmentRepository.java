package com.healthcare.healthcare.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.healthcare.healthcare.model.Appointment;
//import com.healthcare.healthcare.model.MedicalStaff;
//import com.healthcare.healthcare.model.Patient;

public interface AppointmentRepository extends JpaRepository<Appointment, Integer> {
//	 @Query("SELECT DISTINCT a.patient FROM Appointment a WHERE a.medicalStaff.staffId = :staffId")
//	    List<Patient> findPatientsByStaffId(@Param("staffId") int staffId);
//	 
//	 @Query("SELECT DISTINCT a.medicalStaff FROM Appointment a WHERE a.patient.patientId = :patientId")
//		List<MedicalStaff> findStaffByPatientId(int patientId);
//
//	
	
}

