package com.healthcare.healthcare.model;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class MedicalRecord {
    @Id
    private int recordId;
    private int patientId;
    private int staffId;
    private Date dateOfVisit;
    private String symptomDescription;
    private String diagnosis;
    private String treatment;
	public int getRecordId() {
		return recordId;
	}
	public void setRecordId(int recordId) {
		this.recordId = recordId;
	}
	public int getPatientId() {
		return patientId;
	}
	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}
	public int getStaffId() {
		return staffId;
	}
	public void setStaffId(int staffId) {
		this.staffId = staffId;
	}
	public Date getDateOfVisit() {
		return dateOfVisit;
	}
	public void setDateOfVisit(Date dateOfVisit) {
		this.dateOfVisit = dateOfVisit;
	}
	public String getSymptomDescription() {
		return symptomDescription;
	}
	public void setSymptomDescription(String symptomDescription) {
		this.symptomDescription = symptomDescription;
	}
	public String getDiagnosis() {
		return diagnosis;
	}
	public void setDiagnosis(String diagnosis) {
		this.diagnosis = diagnosis;
	}
	public String getTreatment() {
		return treatment;
	}
	public void setTreatment(String treatment) {
		this.treatment = treatment;
	}
	@Override
	public String toString() {
		return "MedicalRecord [recordId=" + recordId + ", patientId=" + patientId + ", staffId=" + staffId
				+ ", dateOfVisit=" + dateOfVisit + ", symptomDescription=" + symptomDescription + ", diagnosis="
				+ diagnosis + ", treatment=" + treatment + ", getRecordId()=" + getRecordId() + ", getPatientId()="
				+ getPatientId() + ", getStaffId()=" + getStaffId() + ", getDateOfVisit()=" + getDateOfVisit()
				+ ", getSymptomDescription()=" + getSymptomDescription() + ", getDiagnosis()=" + getDiagnosis()
				+ ", getTreatment()=" + getTreatment() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
				+ ", toString()=" + super.toString() + "]";
	}
	public MedicalRecord(int recordId, int patientId, int staffId, Date dateOfVisit, String symptomDescription,
			String diagnosis, String treatment) {
		super();
		this.recordId = recordId;
		this.patientId = patientId;
		this.staffId = staffId;
		this.dateOfVisit = dateOfVisit;
		this.symptomDescription = symptomDescription;
		this.diagnosis = diagnosis;
		this.treatment = treatment;
	}
	public MedicalRecord() {
		super();
		// TODO Auto-generated constructor stub
	}

    // Constructors, getters, setters, other methods
}
