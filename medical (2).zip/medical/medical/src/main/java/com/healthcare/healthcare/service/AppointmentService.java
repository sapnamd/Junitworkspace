package com.healthcare.healthcare.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.healthcare.healthcare.model.Appointment;
import com.healthcare.healthcare.repository.AppointmentRepository;


@Service
public class AppointmentService {
    @Autowired
    private AppointmentRepository appointmentRepository;

    public List<Appointment> getAllAppointments() {
        return appointmentRepository.findAll();
    }

    public Optional<Appointment> getAppointmentById(int id) {
        return appointmentRepository.findById(id);
    }

    public Appointment addAppointment(Appointment appointment) {
        return appointmentRepository.save(appointment);
    }

    public Appointment updateAppointment(int id, Appointment updatedAppointment) {
        Optional<Appointment> appointment = appointmentRepository.findById(id);
        if (appointment.isPresent()) {
            updatedAppointment.setAppointmentId(id);
            return appointmentRepository.save(updatedAppointment);
        } else {
            return null;
        }
    }

    public void deleteAppointment(int id) {
        appointmentRepository.deleteById(id);
    }
//    public List<Patient> getPatientsByStaffId(int staffId) {
//        return appointmentRepository.findPatientsByStaffId(staffId);
//    }
//    
//    public List<MedicalStaff> getStaffByPatientId(int patientId) {
//        return appointmentRepository.findStaffByPatientId(patientId);
//    }
}
