package com.healthcare.healthcare.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.healthcare.healthcare.exception.CustomException;
import com.healthcare.healthcare.model.MedicalRecord;
import com.healthcare.healthcare.repository.MedicalRecordRepository;

@Service
public class MedicalRecordServiceImpl implements MedicalRecordService {

    @Autowired
    private MedicalRecordRepository medicalRecordRepository;

    @Override
    public Iterable<MedicalRecord> getAllMedicalRecords() {
        return medicalRecordRepository.findAll();
    }

    @Override
    public MedicalRecord getMedicalRecordById(int recordId) {
        Optional<MedicalRecord> medicalRecordOptional = medicalRecordRepository.findById(recordId);
        return medicalRecordOptional.orElseThrow(() -> new CustomException("Medical Record not found with ID: " + recordId));
    }

    @Override
    public MedicalRecord createMedicalRecord(MedicalRecord medicalRecord) {
        return medicalRecordRepository.save(medicalRecord);
    }

    @Override
    public MedicalRecord updateMedicalRecord(int recordId, MedicalRecord medicalRecord) {
        Optional<MedicalRecord> existingRecordOptional = medicalRecordRepository.findById(recordId);
        if (existingRecordOptional.isPresent()) {
            MedicalRecord existingRecord = existingRecordOptional.get();
            // Update the existingRecord fields here using setters
            existingRecord.setDateOfVisit(medicalRecord.getDateOfVisit());
            existingRecord.setSymptomDescription(medicalRecord.getSymptomDescription());
            existingRecord.setDiagnosis(medicalRecord.getDiagnosis());
            existingRecord.setTreatment(medicalRecord.getTreatment());
            return medicalRecordRepository.save(existingRecord);
        } else {
            throw new CustomException("Medical Record not found with ID: " + recordId);
        }
    }

    @Override
    public void deleteMedicalRecord(int recordId) {
        Optional<MedicalRecord> medicalRecordOptional = medicalRecordRepository.findById(recordId);
        if (medicalRecordOptional.isPresent()) {
            medicalRecordRepository.deleteById(recordId);
        } else {
            throw new CustomException("Medical Record not found with ID: " + recordId);
        }
    }
}
