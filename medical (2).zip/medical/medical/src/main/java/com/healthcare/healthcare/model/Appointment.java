package com.healthcare.healthcare.model;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Appointment {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) // Or other appropriate strategy
	@Column(name = "appointment_id")
	private Long appointmentId;
    
//    @ManyToOne
//    @JoinColumn(name = "patient_id")
//    private Patient patient;
//
//    @ManyToOne
//    @JoinColumn(name = "staff_id")
//    private MedicalStaff medicalStaff;
    
    private Date appointmentDate;
    private String diagnosis;
    private String prescription;
	public long getAppointmentId() {
		return appointmentId;
	}
	public void setAppointmentId(long appointmentId) {
		this.appointmentId = appointmentId;
	}
//	public Patient getPatient() {
//		return patient;
//	}
//	public void setPatient(Patient patient) {
//		this.patient = patient;
//	}
//	public MedicalStaff getMedicalStaff() {
//		return medicalStaff;
//	}
//	public void setMedicalStaff(MedicalStaff medicalStaff) {
//		this.medicalStaff = medicalStaff;
//	}
	public Date getAppointmentDate() {
		return appointmentDate;
	}
	public void setAppointmentDate(Date appointmentDate) {
		this.appointmentDate = appointmentDate;
	}
	public String getDiagnosis() {
		return diagnosis;
	}
	public void setDiagnosis(String diagnosis) {
		this.diagnosis = diagnosis;
	}
	public String getPrescription() {
		return prescription;
	}
	public void setPrescription(String prescription) {
		this.prescription = prescription;
	}
//	public Appointment(long appointmentId, Patient patient, MedicalStaff medicalStaff, Date appointmentDate,
//			String diagnosis, String prescription) {
//		super();
//		this.appointmentId = appointmentId;
////		this.patient = patient;
////		this.medicalStaff = medicalStaff;
//		this.appointmentDate = appointmentDate;
//		this.diagnosis = diagnosis;
//		this.prescription = prescription;
//	}
//	@Override
//	public String toString() {
//		return "Appointment [appointmentId=" + appointmentId + ", patient=" + patient + ", medicalStaff=" + medicalStaff
//				+ ", appointmentDate=" + appointmentDate + ", diagnosis=" + diagnosis + ", prescription=" + prescription
//				+ ", getAppointmentId()=" + getAppointmentId() + ", getPatient()=" + getPatient()
//				+ ", getMedicalStaff()=" + getMedicalStaff() + ", getAppointmentDate()=" + getAppointmentDate()
//				+ ", getDiagnosis()=" + getDiagnosis() + ", getPrescription()=" + getPrescription() + ", getClass()="
//				+ getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
//	}
	public Appointment() {
		super();
		// TODO Auto-generated constructor stub
	}

}
