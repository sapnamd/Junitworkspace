package com.example.demo.junit.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.junit.dao.UserDao;

@Service
public class UserService {

	@Autowired
	private UserDao userdao;

	public String getUseruserIdByName(String name) {
		System.out.print("UserService Called");
		return userdao.getUserId(name);
	}
}
